from django.apps import AppConfig


class EcomConfig(AppConfig):
    name = 'ecom'
